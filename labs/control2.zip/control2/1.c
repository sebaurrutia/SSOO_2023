#include<stdio.h>

int main(){
    char palabra[30];
    printf("ingrese una palabra");
    scanf("%s",&palabra);
    printf("la letra es : %s \n", palabra);

 return 0;
}