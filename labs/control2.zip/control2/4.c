/*Realizar un algoritmo que produzca por pantalla lo siguiente:*/
#include<stdio.h>
#include<string.h>

int main(){
    printf("1   100,110,120,130,140,150\n");
    printf("2   100,110,120,130,140,150\n");
    printf("3   100,110,120,130,140,150\n");
    printf("4   100,110,120,130,140,150\n");
    printf("5   100,110,120,130,140,150\n");
    printf("6   100,110,120,130,140,150\n");
    printf("7   100,110,120,130,140,150\n");
    printf("8   100,110,120,130,140,150\n");
    printf("9   100,110,120,130,140,150\n");
    printf("10   100,110,120,130,140,150\n");

    return 0;
}